# SPDX-License-Identifier: GPL-3.0
# Copyright (c) 2014-2026 William Edwards <shadowapex@gmail.com>, Benjamin Bean <superman2k5@gmail.com>
from __future__ import annotations

import logging
from enum import Enum, auto
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from tuxemon.db import EventObject, ParameterizableRule, SpatialCondition
    from tuxemon.event.eventaction import EventAction
    from tuxemon.event.eventcondition import ConditionManager
    from tuxemon.session import Session


logger = logging.getLogger(__name__)


class EventState(Enum):
    WAITING = auto()
    RUNNING = auto()
    COMPLETED = auto()
    CANCELLED = auto()


class RunningEvent:
    """
    Manage MapEvents that are used during gameplay.

    Running events are considered to have all conditions satisfied.
    Once started, they will eventually execute all actions of the MapEvent.
    RunningEvents do not preserve state between calls or maps.

    RunningEvents have an action_index.
    The action_index is the index of the action list of the action currently
    running.
    The current_action attribute is the instance of the running action.

    Actions being managed by the RunningEvent class can share information
    using the context dictionary.

    Parameters:
        map_event: Event defined in the map containing the information
            about the actions.
    """

    __slots__ = (
        "map_event",
        "actions",
        "context",
        "action_index",
        "current_action",
        "state",
        "priority",
        "elapsed_time",
    )

    def __init__(
        self,
        map_event: EventObject,
        expanded_actions: list[ParameterizableRule],
    ) -> None:
        self.map_event = map_event
        self.actions = expanded_actions
        self.context: dict[str, Any] = {}
        self.action_index: int = 0
        self.current_action: EventAction | None = None
        self.state = EventState.WAITING
        self.priority = map_event.priority
        self.elapsed_time: float = 0.0

    def tick(self, dt: float) -> bool:
        self.elapsed_time += dt

        # Check for delay
        if self.map_event.delay and self.elapsed_time < self.map_event.delay:
            return False

        # Watchdog: Timeout prevents infinite event hangs
        if (
            self.map_event.timeout
            and self.elapsed_time > self.map_event.timeout
        ):
            logger.warning(
                f"Event {self.map_event.id} reached timeout of {self.map_event.timeout}s"
            )
            self.cancel()
            return False

        return True

    def get_next_action(self) -> ParameterizableRule | None:
        """
        Get the next action to execute, if any.

        Returns MapActions, which are just data from the map, not live objects.

        ``None`` will be returned if the MapEvent is finished.

        Returns:
            Next action to execute. ``None`` if there isn't one.
        """
        try:
            return self.actions[self.action_index]
        except IndexError:
            return None

    def advance(self) -> None:
        if self.action_index < len(self.actions):
            self.action_index += 1

    def cancel(self) -> None:
        self.state = EventState.CANCELLED

    def complete(self) -> None:
        self.state = EventState.COMPLETED

    def running(self) -> None:
        self.state = EventState.RUNNING

    def is_cancelled(self) -> bool:
        return self.state == EventState.CANCELLED

    def is_running(self) -> bool:
        return self.state == EventState.RUNNING

    def __repr__(self) -> str:
        """String representation for debugging."""
        return (
            f"<RunningEvent ID={self.map_event.id} "
            f"State={self.state.name} "
            f"Priority={self.priority} "
            f"ActionIndex={self.action_index}>"
        )


class ConditionState(Enum):
    WAITING = auto()
    CHECKING = auto()
    MET = auto()
    FAILED = auto()
    CANCELLED = auto()


class RunningCondition:
    __slots__ = (
        "map_condition",
        "evaluator",
        "state",
        "result",
    )

    def __init__(
        self, map_condition: SpatialCondition, evaluator: ConditionEvaluator
    ) -> None:
        self.map_condition = map_condition
        self.evaluator = evaluator
        self.state = ConditionState.WAITING
        self.result: bool | None = None

    def start_check(self) -> None:
        self.state = ConditionState.CHECKING

    def cancel(self) -> None:
        self.state = ConditionState.CANCELLED

    def is_cancelled(self) -> bool:
        return self.state == ConditionState.CANCELLED

    def is_met(self) -> bool:
        return self.state == ConditionState.MET

    def is_failed(self) -> bool:
        return self.state == ConditionState.FAILED

    def check(self) -> bool:
        if self.is_cancelled():
            self.result = False
            return False

        self.start_check()
        try:
            passed = self.evaluator.evaluate(self.map_condition)
            self.result = passed
            self.state = (
                ConditionState.MET if passed else ConditionState.FAILED
            )
            return passed
        except Exception as e:
            logger.error(
                f"Error checking condition '{self.map_condition}': {e}"
            )
            self.state = ConditionState.FAILED
            self.result = False
            return False


class ConditionEvaluator:
    def __init__(self, session: Session, condition_manager: ConditionManager):
        self.session = session
        self.condition_manager = condition_manager

    def evaluate(self, map_condition: SpatialCondition) -> bool:
        condition = self.condition_manager.get_condition(map_condition)
        if condition is None:
            raise ValueError(
                f"Condition type '{map_condition.type}' not found."
            )

        try:
            self.session.current_condition_box = map_condition.box
            result = condition.test(self.session)
        finally:
            self.session.current_condition_box = None

        return result == condition.is_expected
